import time

import pyrebase
import json
# !/usr/bin/env python
import pika
import time

config = {
    "apiKey": "AIzaSyCOq1yZm5qzTvf8JWyTUFX7fNdlBfzPO30",
    "authDomain": "towtruck-aee55.firebaseapp.com",
    "databaseURL": "https://towtruck-aee55-default-rtdb.firebaseio.com",
    "projectId": "towtruck-aee55",
    "storageBucket": "towtruck-aee55.appspot.com",
    "messagingSenderId": "1089748412963",
    "appId": "1:1089748412963:web:a41b9a9f5ecda122839f96",
    "measurementId": "G-1QE6K6CMJ7"
}

firebase = pyrebase.initialize_app(config)
database = firebase.database()

Accidents = database.child("AccidentHistory").get()
AccidentID = database.child("AccidentHistory").child("Incident1").child("AccidentID").get()
Address = database.child("AccidentHistory").child("Incident1").child("Address").get()
AmountOfCarsInvolved = database.child("AccidentHistory").child("Incident1").child("AmountOfCarsInvolved").get()
Time = database.child("AccidentHistory").child("Incident1").child("Time").get()


def getAndSendAccidentHistory():
    connection = pika.BlockingConnection(
        pika.ConnectionParameters(host='localhost'))
    channel = connection.channel()

    allData = database.get().val()
    accidentHistory = allData.get("AccidentHistory")
    accidents = accidentHistory.keys()

    for accident in accidents:
        accident = accidentHistory.get(accident)

        msg = json.dumps(accident)
        toSend2 = str.encode(msg)

        channel.queue_declare(queue='accidentHistory')
        channel.basic_publish(exchange='', routing_key='accidentHistory', body=toSend2)

    connection.close()

while(1):
    getAndSendAccidentHistory()
    time.sleep(4)