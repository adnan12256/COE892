# UDP SERVER
import socket
import pyrebase
import json
# !/usr/bin/env python
import pika

config = {
    "apiKey": "AIzaSyCOq1yZm5qzTvf8JWyTUFX7fNdlBfzPO30",
    "authDomain": "towtruck-aee55.firebaseapp.com",
    "databaseURL": "https://towtruck-aee55-default-rtdb.firebaseio.com",
    "projectId": "towtruck-aee55",
    "storageBucket": "towtruck-aee55.appspot.com",
    "messagingSenderId": "1089748412963",
    "appId": "1:1089748412963:web:a41b9a9f5ecda122839f96",
    "measurementId": "G-1QE6K6CMJ7"
}

firebase = pyrebase.initialize_app(config)
database = firebase.database()

# Creating a UDP socket server
HostName = socket.gethostname()
Port = 6666
bufferSize = 1024

# Create a socket
try:
    UDPSocketServer = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)
    print('Socket Created!')
except socket.error:
    print('Socket NOT Created!')

# Bind socket to host name and port
try:
    UDPSocketServer.bind((HostName, Port))
    print("Binded! ")
except socket.error:
    print("Can't Bind!")

print("UDP Server Ready!")

while True:
    # Wait here and listen for incoming datagrams
    if (UDPSocketServer.recv != None):
        # receive message from the client
        received = UDPSocketServer.recvfrom(bufferSize)
        data = received[0].decode()

        data = data.split("-")
        data = list(data)
        truckSender = data[0]
        message = data[1]
        truckReceiver = data[2]

        data = {"Message":message}
        database.child("Communication").child(truckReceiver).child(truckSender).set(data)


