#!/`usr/bin/env python
import json
import os
import pika
import sys
import random
import socket


connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))
channel = connection.channel()
channel.queue_declare(queue='accidentHistory')

accidents = []
busy = []
trafficIntersections = ""

while(1):

    def sendToTowTruck(sender, message, receiver):
        serverUDPAddress = (socket.gethostname(), 6666)
        bufferSize = 1024
        IP = socket.gethostname()
        Port = 1111

        # Create a UDP socket at client side
        try:
            UDPClientSocket = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)
        except socket.error:
            print('Socket NOT Created!')

        try:
            UDPClientSocket.bind((IP, Port))
        except socket.error:
            print("Client Can't Bind")

        def sendData(msg):
            # Send received message back to server
            toSend2 = str.encode(msg)
            UDPClientSocket.sendto(toSend2, serverUDPAddress)

        msg= sender + "-" + message + "-" + "Truck"+receiver
        print(msg)
        sendData(msg)


    def callback1(ch, method, properties, body):
        global accidents
        accidents.append(body.decode())

    channel.basic_consume(queue='accidentHistory', on_message_callback=callback1, auto_ack=True)

    channel.queue_declare(queue='TrafficIntersection')

    def callback2(ch, method, properties, body):
        global trafficIntersections
        trafficIntersections=str(body.decode())

    channel.basic_consume(queue='TrafficIntersection', on_message_callback=callback2, auto_ack=True)

    channel.queue_declare(queue='TruckLocations')

    def callback3(ch, method, properties, body):
        global busy
        trucks = str(body.decode()).replace("\'", "\"")
        # trucks = str(body.decode())
        trucksJson = json.loads(trucks)
        truckNumbers = trucksJson.keys()
        amountOfTrucks = len(truckNumbers)

        for accident in accidents:
            accidentJson = json.loads(accident)

            truckDispatched = random.randint(1, amountOfTrucks)
            while truckDispatched in busy:
                truckDispatched = random.randint(1, amountOfTrucks)

            message = "Accident Info: " + str(accident) + "      Avoid High Traffic Intersections: " + trafficIntersections
            sendToTowTruck("Dispatcher", message, str(truckDispatched))
            busy.append(truckDispatched)


    channel.basic_consume(queue='TruckLocations', on_message_callback=callback3, auto_ack=True)

    print(' [*] Waiting for messages. To exit press CTRL+C')
    channel.start_consuming()


