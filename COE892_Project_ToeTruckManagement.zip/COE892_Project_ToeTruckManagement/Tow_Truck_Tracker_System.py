import pyrebase
import json
# !/usr/bin/env python
import pika
import time

config = {
    "apiKey": "AIzaSyCOq1yZm5qzTvf8JWyTUFX7fNdlBfzPO30",
    "authDomain": "towtruck-aee55.firebaseapp.com",
    "databaseURL": "https://towtruck-aee55-default-rtdb.firebaseio.com",
    "projectId": "towtruck-aee55",
    "storageBucket": "towtruck-aee55.appspot.com",
    "messagingSenderId": "1089748412963",
    "appId": "1:1089748412963:web:a41b9a9f5ecda122839f96",
    "measurementId": "G-1QE6K6CMJ7"
}

firebase = pyrebase.initialize_app(config)
database = firebase.database()


def towTruckTracker():
    connection = pika.BlockingConnection(
        pika.ConnectionParameters(host='localhost'))
    channel = connection.channel()

    allData = database.get().val()
    truckLocations = allData.get("TruckLocation")

    channel.queue_declare(queue='TruckLocations')
    channel.basic_publish(exchange='', routing_key='TruckLocations', body=str(truckLocations))

    connection.close()

while(1):
    towTruckTracker()
    time.sleep(4)
