# Client UDP socket code

import socket
import pyrebase

serverUDPAddress = (socket.gethostname(), 6666)
bufferSize = 1024
IP = socket.gethostname()
Port = 1111

# Create a UDP socket at client side
try:
    UDPClientSocket = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)
    print('Socket Created!')
except socket.error:
    print('Socket NOT Created!')

try:
    UDPClientSocket.bind((IP, Port))
    print("Client Binded")
except socket.error:
    print("Client Can't Bind")


def sendData(msg):
    # Send received message back to server
    toSend2 = str.encode(msg)
    UDPClientSocket.sendto(toSend2, serverUDPAddress)


config = {
    "apiKey": "AIzaSyCOq1yZm5qzTvf8JWyTUFX7fNdlBfzPO30",
    "authDomain": "towtruck-aee55.firebaseapp.com",
    "databaseURL": "https://towtruck-aee55-default-rtdb.firebaseio.com",
    "projectId": "towtruck-aee55",
    "storageBucket": "towtruck-aee55.appspot.com",
    "messagingSenderId": "1089748412963",
    "appId": "1:1089748412963:web:a41b9a9f5ecda122839f96",
    "measurementId": "G-1QE6K6CMJ7"
}

firebase = pyrebase.initialize_app(config)
database = firebase.database()

while True:
    print("Enter 1 to send Message, 2 to check for received messages or 0 to exit")
    choice = input()
    if choice == "0":
        break

    elif choice == "1":
        print("Enter Truck Number")
        truckNum = input()
        print("Enter Message")
        message = input()
        print("Enter Destination Truck")
        destination = input()

        totalMsg = truckNum + "-" + message + "-" + destination
        sendData(totalMsg)
        print("Message has been sent")
    elif choice == "2":
        truckNum = input("Enter you truck number")
        allData = database.get().val()
        messageHistory = allData.get("Communication")
        trucks = messageHistory.keys()

        for truck in trucks:
            if truck == truckNum:
                truckMessages = messageHistory.get(truck)
                for message in truckMessages:
                    print("Received From: " + message + " Message: "+truckMessages.get(message).get("Message"))

    else:
        print("Invalid input")
