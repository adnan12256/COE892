import hashlib
import threading
from random import randint
import requests
import json
import time

# arr = [[0, 0, 156, 0, 234, 0],
#        [0, 456, 245, 0, 0, 0],
#        [234, 0, 0, 0, 0, 0],
#        [0, 0, 0, 236, 198, 0]]

class Pos:
    xpos = 0
    ypos = 0

    def __init__(self, x, y):
        Pos.xpos = Pos.xpos + x
        Pos.ypos = Pos.ypos + y


q = open("mine.txt", "r")
map = []
arr = []
for line in q:
    stripedL = line.rstrip()
    row = stripedL.split(' ')
    map.append(row)
w = 0
for i in map:
    if w >= 1:
        arr.append(i)
    w = w + 1


def hash(serialnum):
    pin = randint(0, 20)
    tempMineKey = str(pin) + str(serialnum)
    encode = tempMineKey.encode()
    hash = hashlib.sha256(encode).hexdigest()
    return hash

def algo(i):
    print("Rover number " + str(i) + " start:")
    Pos.xpos = 0
    Pos.ypos = 0
    arr2 = [["", "", "", "", "", ""],
            ["", "", "", "", "", ""],
            ["", "", "", "", "", ""],
            ["", "", "", "", "", ""]]

    # Starting position for all rovers
    arr2[0][0] = "*"
    URL = "https://coe892.reev.dev/lab1/rover/" + str(i)
    response = requests.get(URL)
    data = response.text
    y = json.loads(data)
    # print(len(y['data']['moves']))
    val = y['data']['moves']
    print("Commands: " + val)

    t = 0
    for q in val:
        dug = val[t + 1]
        if t < len(val) - 2:
            t = t + 1
        dugged = 0
        if dug == "D":
            dugged = 1
        if q == "M":
            print("Move Forward")
            if (Pos.xpos + 1 < 0) or (Pos.xpos + 1 >= len(arr)) or (Pos.ypos < 0) or (Pos.ypos >= len(arr[0])):
                print("Cant move forward, stay in the current spot")
                pass
            else:
                if int(arr[Pos.xpos + 1][Pos.ypos]) > 0:
                    if dugged == 1:
                        print("dig")
                        arr[Pos.xpos + 1][Pos.ypos] = "0"
                        Pos(1, 0)
                        arr2[Pos.xpos][Pos.ypos] = "*"
                        val = hash(int(arr[Pos.xpos + 1][Pos.ypos]))
                        print(val)
                        continue
                    print("mine exploded")
                    Pos(1, 0)
                    print("[" + str(Pos.xpos) + "," + str(Pos.ypos) + "]")
                    arr[Pos.xpos][Pos.ypos] = "0"
                    arr2[Pos.xpos][Pos.ypos] = "*"
                    break
                else:
                    print("safe")
                    Pos(1, 0)
                    arr2[Pos.xpos][Pos.ypos] = "*"

        elif q == "L":
            print("Turn Left")
            if (Pos.xpos < 0) or (Pos.xpos >= len(arr)) or (Pos.ypos - 1 < 0) or (Pos.ypos - 1 >= len(arr[0])):
                print("Cant turn left, stay in the current spot")
                pass
            else:
                if int(arr[Pos.xpos][Pos.ypos - 1]) == 0:
                    if dugged == 1:
                        print("dig")
                        arr[Pos.xpos][Pos.ypos - 1] = "0"
                        Pos(0, -1)
                        arr2[Pos.xpos][Pos.ypos] = "*"
                        val = hash(int(arr[Pos.xpos + 1][Pos.ypos]))
                        print(val)
                        continue
                    print("mine exploded")
                    Pos(0, -1)
                    arr2[Pos.xpos][Pos.ypos] = "*"
                    print("[" + str(Pos.xpos) + "," + str(Pos.ypos) + "]")
                    arr[Pos.xpos][Pos.ypos] = "0"
                    break
                else:
                    print("safe")
                    Pos(0, -1)
                    arr2[Pos.xpos][Pos.ypos] = "*"

        elif q == "R":
            print("Turn Right")
            if (Pos.xpos < 0) or (Pos.xpos >= len(arr)) or (Pos.ypos + 1 < 0) or (Pos.ypos + 1 >= len(arr[0])):
                print("Cant turn right, stay in the current spot")
                pass
            else:
                if int(arr[Pos.xpos][Pos.ypos + 1]) > 0:
                    if dugged == 1:
                        print("dig")
                        arr[Pos.xpos][Pos.ypos + 1] = "0"
                        Pos(0, 1)
                        arr2[Pos.xpos][Pos.ypos] = "*"
                        val = hash(int(arr[Pos.xpos + 1][Pos.ypos]))
                        print(val)
                        continue
                    print("mine exploded")
                    Pos(0, 1)
                    arr2[Pos.xpos][Pos.ypos] = "*"
                    print("[" + str(Pos.xpos) + "," + str(Pos.ypos) + "]")
                    arr[Pos.xpos][Pos.ypos] = "0"
                    break
                else:
                    print("safe")
                    Pos(0, 1)
                    arr2[Pos.xpos][Pos.ypos] = "*"

        print("[" + str(Pos.xpos) + "," + str(Pos.ypos) + "]")
    print("Rover number " + str(i) + " completed")
    print("")
    print("Status of the 2D Array:")
    for a in arr:
        print(a)
    print("")
    print("Path of Rover number " + str(i) + ":")
    f = open("path_" + str(i) + ".txt", "w+")
    for b in arr2:
        f.write(str(b) + "\n")
        print(b)
    f.close()
    print("_______________________________________________")


time1 = time.time()
# algo(2)
a = threading.Thread(target=algo(2))
a.start
time2 = time.time()
print(time2 - time1)
