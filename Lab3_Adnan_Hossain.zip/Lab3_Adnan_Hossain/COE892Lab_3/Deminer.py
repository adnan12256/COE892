#!/usr/bin/env python
import pika
import sys
import os
from random import randint
import hashlib


def main():
    connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))
    channel = connection.channel()
    channel.queue_declare(queue='Demine-Queue')


    def callback(ch, method, properties, body):
        serialnum = body.decode()
        # print(body)
        print("Received packet: (" + serialnum + ")")
        serialnum = list(serialnum.split(","))
        print("coordinates: " + serialnum[1] + "," + serialnum[2])
        pin = randint(0, 20)
        tempMineKey = str(pin) + str(serialnum[0])
        encode = tempMineKey.encode()
        hash = hashlib.sha256(encode).hexdigest()
        print("Mine pin number : " + hash)

        demineNum = -1
        while demineNum != "1" and demineNum != "2":
            demineNum = input("Enter deminer number 1 to disable to disarm the mine or 2 to skip the mine: ")
        if demineNum == "1":
            connection2 = pika.BlockingConnection(
                pika.ConnectionParameters(host='localhost'))
            channel2 = connection.channel()
            channel2.queue_declare(queue='Defused-Mines')

            channel2.basic_publish(exchange='', routing_key='Defused-Mines', body=hash)
            print(" [x] Sent Pin Number")
            print("__________________________________________________________________________")
            connection2.close()
        else:
            print("Mine was skipped and not disarmed")
            print("__________________________________________________________________________")

    channel.basic_consume(queue='Demine-Queue', on_message_callback=callback, auto_ack=True)

    print(' [*] Waiting for messages. To exit press CTRL+C')
    channel.start_consuming()


if __name__ == '__main__':
    try:
        main()

    except KeyboardInterrupt:
        print('Interrupted')
        try:
            sys.exit(0)
        except SystemExit:
            os._exit(0)
