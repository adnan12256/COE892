from __future__ import print_function

import logging
import grpc
from grpc._channel import Channel

import roverP_pb2
import roverP_pb2_grpc
import pika


def run():
    with grpc.insecure_channel('localhost:50051') as channel:
        class Pos:
            xpos = 0
            ypos = 0

            def __init__(self, x, y):
                Pos.xpos = Pos.xpos + x
                Pos.ypos = Pos.ypos + y

        # for i in range(1, 11):
        i = -1
        while i != 0:
            i = input("Enter the rover number to start or enter 0 to exit the program: ")
            connection = pika.BlockingConnection(
                pika.ConnectionParameters(host='localhost'))
            channel2 = connection.channel()
            channel2.queue_declare(queue='Demine-Queue')
            if i == "0":
                break
            stub1 = roverP_pb2_grpc.readMapStub(channel)
            response1 = stub1.getMap(roverP_pb2.mapRequest(request='1'))
            arr = response1.map
            arr = arr[1: -1:]
            arr2 = ""
            for c in arr:
                if c == "0" or c == "1" or c == "2" or c == "3" or c == "4" or c == "5" or c == "6" or c == "7" or c == "8" or c == "9" or c == "0" or c == ",":
                    arr2 = (arr2 + c)
            arr2 = list(arr2.split(","))
            # arr has all the values of the map in a list
            arr = [arr2[x:x + 6] for x in range(0, len(arr2), 6)]
            # print(arr[0])

            # Start of the main code block
            print("Rover number " + str(i) + " start:")
            Pos.xpos = 0
            Pos.ypos = 0
            arr2 = [["", "", "", "", "", ""],
                    ["", "", "", "", "", ""],
                    ["", "", "", "", "", ""],
                    ["", "", "", "", "", ""]]

            # Starting position for all rovers
            arr2[0][0] = "*"

            stub2 = roverP_pb2_grpc.readCommandStub(channel)
            response2 = stub2.getCommand(roverP_pb2.commandRequest(roverNum=str(i)))
            val = response2.val
            print("Commands:" + val)
            t = 0

            for q in val:
                if q == "M":
                    print("Move Forward")
                    if (Pos.xpos + 1 < 0) or (Pos.xpos + 1 >= len(arr)) or (Pos.ypos < 0) or (Pos.ypos >= len(arr[0])):
                        print("Cant move forward, stay in the current spot")
                        pass
                    else:
                        if int(arr[Pos.xpos + 1][Pos.ypos]) > 0:
                            print("Mine is sent to the Deminer")
                            Pos(1, 0)
                            print("Current Position: [" + str(Pos.xpos) + "," + str(Pos.ypos) + "]")
                            # arr[Pos.xpos][Pos.ypos] = "0"
                            arr2[Pos.xpos][Pos.ypos] = "*"
                            serNum = arr[Pos.xpos][Pos.ypos]

                            stub5 = roverP_pb2_grpc.readSerialNumStub(channel)
                            response5 = stub5.getSerialNum(roverP_pb2.SerialNumRequest(serialNum=serNum))
                            val = response5.pin
                            print(val)

                            channel2.basic_publish(exchange='', routing_key='Demine-Queue', body=serNum + "," + str(Pos.xpos) + "," + str(Pos.ypos))
                            print(" [x] Sent 'key'")
                            arr[Pos.xpos][Pos.ypos] = "0"
                            # break
                            continue
                        else:
                            print("safe")
                            Pos(1, 0)
                            arr2[Pos.xpos][Pos.ypos] = "*"

                elif q == "L":
                    print("Turn Left")
                    if (Pos.xpos < 0) or (Pos.xpos >= len(arr)) or (Pos.ypos - 1 < 0) or (Pos.ypos - 1 >= len(arr[0])):
                        print("Cant turn left, stay in the current spot")
                        pass
                    else:
                        if int(arr[Pos.xpos][Pos.ypos - 1]) > 0:
                            print("Mine is sent to the Deminer")
                            Pos(0, -1)
                            arr2[Pos.xpos][Pos.ypos] = "*"
                            print("Current Position: [" + str(Pos.xpos) + "," + str(Pos.ypos) + "]")
                            # arr[Pos.xpos][Pos.ypos] = "0"
                            serNum = arr[Pos.xpos][Pos.ypos]

                            stub5 = roverP_pb2_grpc.readSerialNumStub(channel)
                            response5 = stub5.getSerialNum(roverP_pb2.SerialNumRequest(serialNum=serNum))
                            val = response5.pin
                            print(val)

                            channel2.basic_publish(exchange='', routing_key='Demine-Queue', body=serNum + "," + str(Pos.xpos) + "," + str(Pos.ypos))
                            print(" [x] Sent 'key'")
                            arr[Pos.xpos][Pos.ypos] = "0"
                            # break
                            continue
                        else:
                            print("safe")
                            Pos(0, -1)
                            arr2[Pos.xpos][Pos.ypos] = "*"

                elif q == "R":
                    print("Turn Right")
                    if (Pos.xpos < 0) or (Pos.xpos >= len(arr)) or (Pos.ypos + 1 < 0) or (Pos.ypos + 1 >= len(arr[0])):
                        print("Cant turn right, stay in the current spot")
                        pass
                    else:
                        if int(arr[Pos.xpos][Pos.ypos + 1]) > 0:
                            print("Mine is sent to the Deminer")
                            Pos(0, 1)
                            arr2[Pos.xpos][Pos.ypos] = "*"
                            print("Current Position: [" + str(Pos.xpos) + "," + str(Pos.ypos) + "]")
                            # arr[Pos.xpos][Pos.ypos] = "0"
                            serNum = arr[Pos.xpos][Pos.ypos]

                            stub5 = roverP_pb2_grpc.readSerialNumStub(channel)
                            response5 = stub5.getSerialNum(roverP_pb2.SerialNumRequest(serialNum=serNum))
                            val = response5.pin
                            print(val)

                            channel2.basic_publish(exchange='', routing_key='Demine-Queue', body=serNum + "," + str(Pos.xpos) + "," + str(Pos.ypos))
                            print(" [x] Sent 'key'")
                            arr[Pos.xpos][Pos.ypos] = "0"
                            # break
                            continue
                        else:
                            print("safe")
                            Pos(0, 1)
                            arr2[Pos.xpos][Pos.ypos] = "*"
                elif q == "D":
                    continue

                print("Current Position: [" + str(Pos.xpos) + "," + str(Pos.ypos) + "]")
            print("Rover number " + str(i) + " completed")
            print("")
            print("Status of the 2D Array:")
            for a in arr:
                print(a)
            print("")
            print("Path of Rover number " + str(i) + ":")
            f = open("path_" + str(i) + ".txt", "w+")
            for b in arr2:
                f.write(str(b) + "\n")
                print(b)
            f.close()

            connection.close()
            print("_______________________________________________")


if __name__ == '__main__':
    logging.basicConfig()
    run()
