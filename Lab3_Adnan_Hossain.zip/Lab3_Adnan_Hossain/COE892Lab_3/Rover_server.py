from concurrent import futures
import logging

import grpc
import roverP_pb2
import roverP_pb2_grpc
import requests
import json
import pika

from random import randint
import hashlib


class readMap(roverP_pb2_grpc.readMapServicer):
    def getMap(self, request, context):
        q = open("map.txt", "r")
        map = []
        arr = []
        for line in q:
            stripedL = line.rstrip()
            row = stripedL.split(' ')
            map.append(row)
        w = 0
        for i in map:
            if w >= 1:
                arr.append(i)
            w = w + 1
        return roverP_pb2.mapFile(map=str(arr), rows="4", cols="6")


class readCommand(roverP_pb2_grpc.readCommandServicer):
    def getCommand(self, request, context):
        URL = "https://coe892.reev.dev/lab1/rover/" + str(request.roverNum)
        response = requests.get(URL)
        data = response.text
        y = json.loads(data)
        # print(len(y['data']['moves']))
        val = y['data']['moves']
        val = val + "C"
        print("Commands: " + val)
        return roverP_pb2.commandFile(val=val)


# class readComplete(roverP_pb2_grpc.readCommandServicer):
#     def getComplete(self, request, context):
#         if request.completeStatus == "1" :
#             resp = "All the commands have executed and the rover has completed its path"
#             print(resp)
#         else:
#             resp = "All the commands did not execute and the rover triggered a mine"
#             print(resp)
#         return roverP_pb2.completeFile(response = resp)
#
# class readPin(roverP_pb2_grpc.readPinServicer):
#     def getPin(self, request, context):
#         serialnum = request.serialNum
#         pin = randint(0, 20)
#         tempMineKey = str(pin) + str(serialnum)
#         encode = tempMineKey.encode()
#         hash = hashlib.sha256(encode).hexdigest()
#         print("Mine pin number : " + hash)
#         return roverP_pb2.pinFile(pin = hash)

class readSerialNum(roverP_pb2_grpc.readSerialNumServicer):
    def getSerialNum(self, request, context):
        newString = "SerialNum for the mine getting dug is: " + request.serialNum
        return roverP_pb2.SerialNumFile(pin=newString)


def callback(ch, method, properties, body):
    print(" [x] Mine Pin Number From Defused-Mines Queue: %r" % body.decode())


def serve():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    roverP_pb2_grpc.add_readMapServicer_to_server(readMap(), server)
    roverP_pb2_grpc.add_readCommandServicer_to_server(readCommand(), server)
    # roverP_pb2_grpc.add_readCompleteServicer_to_server(readComplete(), server)
    # roverP_pb2_grpc.add_readPinServicer_to_server(readPin(), server)
    roverP_pb2_grpc.add_readSerialNumServicer_to_server(readSerialNum(), server)
    server.add_insecure_port('[::]:50051')
    server.start()

    connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))
    channel = connection.channel()
    channel.queue_declare(queue='Defused-Mines')
    channel.basic_consume(queue='Defused-Mines', on_message_callback=callback, auto_ack=True)
    print(' [*] Waiting for messages. To exit press CTRL+C')
    channel.start_consuming()

    server.wait_for_termination()
    print("before Defused-Mines")



if __name__ == '__main__':
    logging.basicConfig()
    serve()
